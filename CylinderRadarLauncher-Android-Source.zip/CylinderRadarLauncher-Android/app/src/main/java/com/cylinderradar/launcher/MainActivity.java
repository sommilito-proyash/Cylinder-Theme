package com.cylinderradar.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.*;
import android.os.Bundle;
import android.view.*;
import android.widget.Toast;
import java.util.*;

public class MainActivity extends Activity {
    CylinderView cylinder;
    int themeIndex = 0;
    final int[] colors = {Color.rgb(57,255,136), Color.rgb(0,190,255), Color.rgb(210,75,255), Color.rgb(255,65,75), Color.rgb(255,145,35), Color.rgb(0,235,225)};
    @Override public void onCreate(Bundle b) { super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(2,12,10)); getWindow().setNavigationBarColor(Color.rgb(2,12,10)); cylinder = new CylinderView(); setContentView(cylinder); }
    void chooseColor(){ String[] names={"Radar Green","Electric Blue","Violet","Red","Amber","Cyan"}; new AlertDialog.Builder(this).setTitle("Choose radar color").setSingleChoiceItems(names,themeIndex,(d,w)->{themeIndex=w;cylinder.invalidate();d.dismiss();}).setNegativeButton("Close",null).show(); }
    class AppEntry { String label, pkg; android.graphics.drawable.Drawable icon; AppEntry(String l,String p,android.graphics.drawable.Drawable i){label=l;pkg=p;icon=i;} }
    class CylinderView extends View {
        Paint p=new Paint(3); ArrayList<AppEntry> apps=new ArrayList<>(); float rotation=0,lastX; boolean dragging=false; float downX,downY; long downTime; float density;
        CylinderView(){ super(MainActivity.this); density=getResources().getDisplayMetrics().density; setLayerType(View.LAYER_TYPE_SOFTWARE,null); loadApps(); }
        void loadApps(){ PackageManager pm=getPackageManager(); Intent q=new Intent(Intent.ACTION_MAIN,null); q.addCategory(Intent.CATEGORY_LAUNCHER); List<ResolveInfo> list=pm.queryIntentActivities(q,0); for(ResolveInfo r:list){ if(r.activityInfo.packageName.equals(getPackageName())) continue; apps.add(new AppEntry(r.loadLabel(pm).toString(),r.activityInfo.packageName,r.loadIcon(pm))); } Collections.sort(apps,(a,b)->a.label.compareToIgnoreCase(b.label)); }
        int accent(){return colors[themeIndex];} void paint(int c,float sw){p.setColor(c);p.setStrokeWidth(sw);p.setStyle(Paint.Style.STROKE);p.setShader(null);p.setShadowLayer(0,0,0,0);} void fill(int c){p.setColor(c);p.setStyle(Paint.Style.FILL);p.setShader(null);p.setShadowLayer(0,0,0,0);}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight(),cx=w/2f; int a=accent(); c.drawColor(Color.rgb(2,10,10));
            // subtle radar background
            paint(0x1839ff88,1*density); for(int r=60;r<Math.max(w,h);r+=44)c.drawCircle(cx,h*.43f,r*density,p);
            p.setStyle(Paint.Style.FILL);p.setShader(new LinearGradient(0,0,w,h, new int[]{0xff031b14,0xff02090d,0xff00160f},null,Shader.TileMode.CLAMP));c.drawRect(0,0,w,h,p);p.setShader(null);
            fill(0xffeafff2);p.setTextSize(22*density);p.setTypeface(Typeface.create("sans-serif-medium",Typeface.BOLD));c.drawText("CYLINDER RADAR",18*density,38*density,p);
            fill(a);p.setTextSize(11*density);p.setTypeface(Typeface.DEFAULT);c.drawText("SWIPE TO ROTATE  •  TAP AN APP",19*density,58*density,p);
            float top=h*.22f, bottom=h*.78f, rw=w*.35f, rh=30*density;
            // glowing cylinder shell
            p.setStyle(Paint.Style.FILL);p.setShader(new LinearGradient(cx-rw,0,cx+rw,0,new int[]{0xff02180e,a,0xff06301d,a,0xff010b08},null,Shader.TileMode.CLAMP)); c.drawRect(cx-rw,top,cx+rw,bottom,p);p.setShader(null);
            paint(a,2*density);p.setShadowLayer(16*density,0,0,a);c.drawOval(cx-rw,top-rh,cx+rw,top+rh,p);c.drawOval(cx-rw,bottom-rh,cx+rw,bottom+rh,p);p.clearShadowLayer();
            paint(a,1*density);for(int j=1;j<4;j++){float y=top+(bottom-top)*j/4f;c.drawOval(cx-rw,y-rh*.55f,cx+rw,y+rh*.55f,p);} 
            // rotating app panels
            int count=Math.min(apps.size(),24); if(count==0){fill(Color.WHITE);p.setTextSize(14*density);c.drawText("No launchable apps found",cx-90*density,h*.5f,p);} else {
                for(int i=0;i<count;i++){double ang=(i*2*Math.PI/count)+rotation;float x=cx+(float)Math.sin(ang)*rw*.78f;float depth=(float)Math.cos(ang);if(depth<-.4f)continue;float y=top+rh+(bottom-top-rh*2)*(i%4+.5f)/4f; float scale=.68f+.32f*(depth+1)/2f; float iw=35*density*scale; float iy=y+(float)Math.sin(ang)*12*density;
                    p.setAlpha(255);fill(0x55000000);c.drawRoundRect(x-iw*.75f,iy-iw*.8f,x+iw*.75f,iy+iw*.8f,9*density,9*density,p);
                    AppEntry e=apps.get(i); c.save();c.translate(x-iw/2,iy-iw/2);e.icon.setBounds(0,0,(int)iw,(int)iw);e.icon.draw(c);c.restore();
                    fill(Color.WHITE);p.setTextSize(9*density*scale);p.setTextAlign(Paint.Align.CENTER);String label=e.label.length()>12?e.label.substring(0,11)+"…":e.label;c.drawText(label,x,iy+iw*.8f+10*density,p);p.setTextAlign(Paint.Align.LEFT);
                }
            }
            // radar beam and base rings
            paint(a,2*density);p.setAlpha(180);p.setShadowLayer(12*density,0,0,a);c.drawArc(cx-rw*.75f,top-rh*.6f,cx+rw*.75f,top+rh*.6f,(rotation*57.3f)%360,75,false,p);p.clearShadowLayer();c.drawOval(cx-rw*1.18f,bottom+rh,cx+rw*1.18f,bottom+rh*1.8f,p);
            fill(a);p.setTextSize(12*density);p.setTypeface(Typeface.create("sans-serif-medium",Typeface.BOLD));String countText=apps.size()+" APPS";c.drawText(countText,18*density,h-60*density,p);c.drawText("COLOR",w-72*density,h-60*density,p);
            float[] xs={w-62*density,w-44*density,w-26*density};for(int i=0;i<3;i++){fill(colors[(themeIndex+i)%colors.length]);c.drawCircle(xs[i],h-36*density,5*density,p);} fill(0xffb9d8ca);p.setTextSize(10*density);p.setTypeface(Typeface.DEFAULT);c.drawText("Tap bottom-right to change theme",18*density,h-25*density,p);
        }
        @Override public boolean onTouchEvent(android.view.MotionEvent e){float x=e.getX(),y=e.getY();switch(e.getAction()){case MotionEvent.ACTION_DOWN:downX=lastX=x;downY=y;downTime=System.currentTimeMillis();dragging=false;return true;case MotionEvent.ACTION_MOVE:float dx=x-lastX;if(Math.abs(x-downX)>5*density)dragging=true;rotation+=dx/(70*density);lastX=x;invalidate();return true;case MotionEvent.ACTION_UP:if(!dragging&&y>getHeight()-90*density&&x>getWidth()*.68f){chooseColor();return true;}if(!dragging&&Math.abs(x-downX)<20*density){openNearest(x,y);}return true;}return true;}
        void openNearest(float x,float y){if(y<75*density){chooseColor();return;} if(apps.isEmpty())return;float cx=getWidth()/2f, top=getHeight()*.22f,bottom=getHeight()*.78f,rw=getWidth()*.35f,rh=30*density;double best=Double.MAX_VALUE;AppEntry selected=null;int count=Math.min(apps.size(),24);for(int i=0;i<count;i++){double ang=(i*2*Math.PI/count)+rotation;float xx=cx+(float)Math.sin(ang)*rw*.78f;float yy=top+rh+(bottom-top-rh*2)*(i%4+.5f)/4f+(float)Math.sin(ang)*12*density;double d=Math.hypot(x-xx,y-yy);if(d<best){best=d;selected=apps.get(i);}}if(selected!=null&&best<95*density){try{Intent launch=getPackageManager().getLaunchIntentForPackage(selected.pkg);if(launch!=null)startActivity(launch);}catch(Exception ex){Toast.makeText(MainActivity.this,"Could not open app",Toast.LENGTH_SHORT).show();}}else if(y>getHeight()*.8f)chooseColor();}
    }
}
